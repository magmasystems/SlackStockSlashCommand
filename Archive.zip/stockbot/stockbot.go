package stockbot

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"strings"

	av "../alphavantageprovider"
	quandl "../quandlprovider"
	q "../quoteproviders"
	wtd "../worldtradingdata"
)

// QuoteInfo - contains info about a quote
type QuoteInfo struct {
	Symbol    string
	LastPrice float32
}

// BotOps - interface defining all operations the Stockbot can do
type BotOps interface {
	Close()
	QuoteSingle(symbol string) []QuoteInfo
	Quote(symbols []string) []QuoteInfo
	Config() AppSettings
}

// Stockbot - the bot that retrieves stock quotes fro a provider
type Stockbot struct {
	quoteProvider q.QuoteProvider
	QuoteReceived chan []QuoteInfo
}

func main() {
	bot := CreateStockbot()
	fmt.Println(bot.QuoteSingle("MSFT"))

	scanner := bufio.NewScanner(os.Stdin)
	print("Enter the symbol: ")
	for scanner.Scan() {
		symbol := scanner.Text()
		if len(symbol) == 0 {
			break
		}
		price := bot.QuoteSingle(symbol)
		fmt.Println(price)
		print("Enter the symbol: ")
	}
}

// CreateStockbot - creates a new instance of the StockBot
func CreateStockbot() *Stockbot {
	bot := new(Stockbot)

	appSettings := bot.Config()
	// apiKey := getArg("apikey", os.Getenv("ALPHAVANTAGE_APIKEY"))
	// driver := getArg("driver", "alphavantage")

	driver := appSettings.Driver
	apiKey := appSettings.APIKeys[driver]
	bot.quoteProvider, _ = quoteProviderFactory(driver, apiKey)
	bot.QuoteReceived = make(chan []QuoteInfo, 20)

	return bot
}

// Close - disposes of the resources of a stock bot
func (bot *Stockbot) Close() {
	if bot.quoteProvider != nil {
		bot.quoteProvider.Close()
	}
}

// QuoteSingle - gets the price for a stock
func (bot *Stockbot) QuoteSingle(symbol string) []QuoteInfo {
	symbols := []string{symbol}
	return bot.Quote(symbols)
}

// Quote - gets the price for a stock
func (bot *Stockbot) Quote(symbols []string) []QuoteInfo {
	n := len(symbols)
	quoteInfo := new([100]QuoteInfo) // I wish we had dynamic list of structs

	for idx, symbol := range symbols {
		if symbol == "" {
			continue
		}
		price := bot.quoteProvider.FetchQuote(symbol)
		quoteInfo[idx].LastPrice = price
		quoteInfo[idx].Symbol = symbol
	}

	bot.QuoteReceived <- quoteInfo[0:n]
	return quoteInfo[0:n]
}

func getArg(key string, defautVal string) string {
	var val string

	for idx, arg := range os.Args {
		switch strings.ToLower(arg) {
		case key:
			val = os.Args[idx+1]
			break
		}
	}

	if len(val) == 0 {
		val = defautVal
	}

	return val
}

// Config - get the config settings from appSettings.json
func (bot *Stockbot) Config() *AppSettings {
	bytes, err := ioutil.ReadFile("appSettings.json")
	if err != nil {
		log.Fatalf("cannot find the appSettings.json file")
	}

	settings := new(AppSettings)
	json.Unmarshal(bytes, &settings)

	return settings
}

// quoteProviderFactory - a factory that creates a quote provider
func quoteProviderFactory(providerName string, apiKey string) (provider q.QuoteProvider, errs error) {
	switch strings.ToLower(providerName) {
	case "alphavantage":
		provider = av.CreateQuoteProvider(apiKey)
	case "worldtradingdata":
		provider = wtd.CreateQuoteProvider(apiKey)
	case "quandl":
		provider = quandl.CreateQuoteProvider(apiKey)
	default:
		return nil, errors.New("the Quote Provider cannot be found")
	}

	return provider, nil
}

// AppSettings - config settings for the bot
type AppSettings struct {
	Driver           string
	APIKeys          map[string]string
	SlackSecret      string
	SlackSecretLocal string
	Port             int
}
